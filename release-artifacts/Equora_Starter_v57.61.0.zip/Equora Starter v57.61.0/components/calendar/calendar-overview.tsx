'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useEffect, useMemo, useState, useTransition } from 'react'
import { CalendarGrid } from '@/components/calendar/calendar-grid'
import { SetupImageLightbox } from '@/components/setups/setup-image-lightbox'
import { SectionHeader } from '@/components/layout/section-header'
import { AppIcon } from '@/components/ui/app-icon'
import { FuturisticCard } from '@/components/ui/futuristic-card'
import type { Trade } from '@/lib/types/trade'
import { formatCurrency, formatPartialExitCoverageLabel, formatPlainNumber, getPartialExitPlanInfo } from '@/lib/utils/calculations'
import { buildCalendarSummary, getDateKeyFromDate, normalizeTradeDate } from '@/lib/utils/calendar'
import { resolveTradeOccurredAt } from '@/lib/utils/trade-time'
import { getMonetaryScopeMessage, resolveMonetaryScope } from '@/lib/utils/currency'

const monthNames = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember']

type CalendarNote = { id: string; dateKey: string; title: string; note: string; mood: string; focus: string }

export function CalendarOverview({
  trades,
  initialYear,
  initialMonth,
}: {
  trades: Trade[]
  initialYear: number
  initialMonth: number
}) {
  const router = useRouter()
  const today = useMemo(() => new Date(), [])
  const todayDateKey = useMemo(() => getDateKeyFromDate(today), [today])
  const year = initialYear
  const month = initialMonth
  const [selectedDateKey, setSelectedDateKey] = useState<string | null>(todayDateKey)
  const [isMonthPending, startMonthTransition] = useTransition()

  const summaries = useMemo(() => buildCalendarSummary(trades), [trades])
  const monthSummaries = useMemo(
    () => summaries.filter((item) => item.year === year && item.month === month),
    [summaries, year, month],
  )
  const monthTrades = useMemo(() => trades.filter((trade) => {
    const date = normalizeTradeDate(resolveTradeOccurredAt(trade))
    return date.getFullYear() === year && date.getMonth() === month
  }), [month, trades, year])
  const monthMonetaryScope = useMemo(() => resolveMonetaryScope(
    monthTrades.filter((trade) => trade.netPnL !== null && trade.netPnL !== undefined).map((trade) => trade.accountCurrency),
  ), [monthTrades])
  const positiveDays = monthSummaries.filter((item) => item.monetaryScope.isComparable && item.netPnL > 0).length
  const negativeDays = monthSummaries.filter((item) => item.monetaryScope.isComparable && item.netPnL < 0).length
  const screenshotDays = monthSummaries.filter((item) => item.screenshotTradeCount > 0).length
  const riskDays = monthSummaries.filter((item) => item.riskTradeCount > 0).length
  const openTradesInMonth = monthSummaries.reduce((sum, item) => sum + item.openTradeCount, 0)
  const comparableMonthSummaries = monthSummaries.filter((item) => item.monetaryScope.isComparable)
  const strongestDay = monthMonetaryScope.isComparable
    ? comparableMonthSummaries.reduce((best, item) => (!best || item.netPnL > best.netPnL ? item : best), comparableMonthSummaries[0])
    : undefined
  const highestMonthRiskPercent = monthSummaries.reduce((best, item) => item.maxActualRiskPercent !== null && item.maxActualRiskPercent !== undefined ? Math.max(best, item.maxActualRiskPercent) : best, 0)

  useEffect(() => {
    if (selectedDateKey) {
      const [selectedYear, selectedMonth] = selectedDateKey.split('-').map(Number)
      if (selectedYear === year && selectedMonth === month + 1) return
    }
    const fallbackDateKey = year === today.getFullYear() && month === today.getMonth()
      ? todayDateKey
      : monthSummaries[monthSummaries.length - 1]?.dateKey ?? null
    setSelectedDateKey(fallbackDateKey)
  }, [monthSummaries, month, selectedDateKey, today, todayDateKey, year])

  const selectedSummary = monthSummaries.find((item) => item.dateKey === selectedDateKey)
  const selectedTrades = useMemo(() => {
    if (!selectedDateKey) return []
    return trades.filter(
      (trade) => getDateKeyFromDate(normalizeTradeDate(resolveTradeOccurredAt(trade))) === selectedDateKey,
    )
  }, [selectedDateKey, trades])
  const selectedNetPnL = selectedTrades.reduce((sum, trade) => sum + (trade.netPnL ?? 0), 0)
  const selectedMonetaryScope = resolveMonetaryScope(
    selectedTrades
      .filter((trade) => trade.netPnL !== null && trade.netPnL !== undefined || trade.plannedRiskAmount || trade.riskAmount || trade.marginUsed)
      .map((trade) => trade.accountCurrency),
  )
  const selectedAvgR = selectedTrades.length
    ? selectedTrades.reduce((sum, trade) => sum + (trade.rValue ?? 0), 0) / selectedTrades.length
    : 0
  const selectedSetups = Array.from(new Set(selectedSummary?.setups ?? []))
  const selectedScreenshots = selectedTrades.filter((trade) => trade.screenshotUrl)
  const selectedPlannedRisk = selectedTrades.reduce((sum, trade) => sum + Math.abs(trade.plannedRiskAmount ?? 0), 0)
  const selectedStopRisk = selectedTrades.reduce((sum, trade) => sum + Math.abs(trade.riskAmount ?? 0), 0)
  const selectedMarginUsed = selectedTrades.reduce((sum, trade) => sum + Math.abs(trade.marginUsed ?? 0), 0)
  const selectedHighestLeverage = selectedTrades.reduce((best, trade) => trade.leverage !== null && trade.leverage !== undefined ? Math.max(best, trade.leverage) : best, 0)
  const selectedRiskCoverageCount = selectedTrades.filter((trade) => trade.actualRiskPercent !== null && trade.actualRiskPercent !== undefined).length
  const selectedRiskCoverageLabel = selectedTrades.length ? `${selectedRiskCoverageCount}/${selectedTrades.length}` : '0/0'
  const selectedHighestRiskPercent = selectedTrades.reduce((best, trade) => trade.actualRiskPercent !== null && trade.actualRiskPercent !== undefined ? Math.max(best, trade.actualRiskPercent) : best, 0)
  const featuredTrade = selectedScreenshots[0] ?? selectedTrades[0]
  const featuredTradeStatus = featuredTrade
    ? featuredTrade.captureResult === 'open'
      ? 'Offen'
      : featuredTrade.captureStatus === 'incomplete' || featuredTrade.isComplete === false
        ? 'Unvollständig'
        : 'Geschlossen'
    : null
  const featuredEntry = featuredTrade ? (featuredTrade as Trade & { entry?: string | number | null }).entry : null
  const featuredPartialPlan = featuredTrade ? getPartialExitPlanInfo({ exit: featuredTrade.effectiveExit ?? null, partialExits: featuredTrade.partialExits ?? [] }) : null
  const featuredPartialLabel = featuredPartialPlan && featuredPartialPlan.count ? formatPartialExitCoverageLabel(featuredPartialPlan.coveredPercent, featuredPartialPlan.remainderPercent) : null
  const remainingScreenshotTrades = selectedScreenshots.filter((trade) => trade.id !== featuredTrade?.id)
  const selectedTradeIdsParam = selectedTrades.map((trade) => trade.id).join('|')
  const selectedTradesHref = selectedTrades.length
    ? `/trades?reviewTradeIds=${encodeURIComponent(selectedTradeIdsParam)}&tradeId=${encodeURIComponent(selectedTrades[0].id)}&reviewFocus=${encodeURIComponent(`Kalender · ${selectedDateKey}`)}#trade-detail`
    : '/trades'

  function navigateToMonth(targetYear: number, targetMonth: number) {
    const normalizedDate = new Date(targetYear, targetMonth, 1)
    const monthKey = `${normalizedDate.getFullYear()}-${String(normalizedDate.getMonth() + 1).padStart(2, '0')}`
    startMonthTransition(() => {
      router.push(`/kalender?month=${monthKey}`)
    })
  }

  function goPrevMonth() {
    navigateToMonth(year, month - 1)
  }

  function goNextMonth() {
    navigateToMonth(year, month + 1)
  }

  function goToday() {
    setSelectedDateKey(todayDateKey)
    navigateToMonth(today.getFullYear(), today.getMonth())
  }

  return (
    <div className="space-y-6">
      <FuturisticCard glow="orange" className="p-5">
        <SectionHeader
          eyebrow="Kalender"
          title="Monat"
          badge={`${monthSummaries.length} aktive Tage`}
        />

        <div className="grid gap-5 xl:grid-cols-[1.05fr_0.95fr]">
          <div className="rounded-3xl border border-orange-400/15 bg-black/25 p-5">
            <p className="text-[10px] uppercase tracking-[0.24em] text-white/35">Monatsrahmen</p>
            <div className="mt-4 flex flex-wrap items-center gap-3">
              <button onClick={goPrevMonth} disabled={isMonthPending} className="rounded-full border border-white/10 bg-black/20 px-3 py-2 text-xs text-white/60 transition hover:border-white/14 hover:text-white/80 disabled:cursor-wait disabled:opacity-50">Zurück</button>
              <div className="rounded-full border border-orange-400/20 bg-orange-400/10 px-4 py-2 text-sm text-orange-100/90">
                {monthNames[month]} {year}
              </div>
              <button onClick={goNextMonth} disabled={isMonthPending} className="rounded-full border border-white/10 bg-black/20 px-3 py-2 text-xs text-white/60 transition hover:border-white/14 hover:text-white/80 disabled:cursor-wait disabled:opacity-50">Weiter</button>
              <button onClick={goToday} disabled={isMonthPending} className="rounded-full border border-orange-400/20 bg-orange-400/10 px-3 py-2 text-xs text-orange-100/90 transition hover:border-orange-400/30 hover:bg-orange-400/15 disabled:cursor-wait disabled:opacity-50">{isMonthPending ? 'Lädt…' : 'Heute'}</button>
            </div>
            <div className="mt-5 flex flex-wrap gap-2 text-xs text-white/55">
              <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5">{positiveDays} grüne Tage</span>
              <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5">{negativeDays} rote Tage</span>
              <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5">{riskDays} Tage mit Risk-Kontext</span>
              <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5">{screenshotDays} Tage mit Bildern</span>
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-2">
            <CalendarHighlightTile label="Aktive Tage" value={String(monthSummaries.length)} detail="mit Trade" icon="calendar" tone="orange" />
            <CalendarHighlightTile label="Offene Trades" value={String(openTradesInMonth)} detail="im Monat" icon="spark" tone="emerald" />
            <CalendarHighlightTile label="Risk-Tage" value={String(riskDays)} detail="mit Risiko" icon="focus" tone="orange" />
            <CalendarHighlightTile label="Höchstes Kontorisiko" value={highestMonthRiskPercent ? `${formatPlainNumber(highestMonthRiskPercent, 2)}%` : '—'} detail={highestMonthRiskPercent ? 'maximal im sichtbaren Monat' : strongestDay ? `${String(strongestDay.day).padStart(2, '0')}. ${monthNames[strongestDay.month]} als stärkster Tag` : monthMonetaryScope.kind === 'mixed' || monthMonetaryScope.kind === 'unknown' ? 'Stärkster Geld-Tag wegen Währungen gesperrt' : 'Noch kein Kontorisiko hinterlegt'} icon="cost" tone={highestMonthRiskPercent > 1 ? 'red' : 'orange'} />
          </div>
        </div>
      </FuturisticCard>

      <FuturisticCard className="p-5">
        <CalendarGrid year={year} month={month} summaries={summaries} selectedDateKey={selectedDateKey} onSelectDay={setSelectedDateKey} />
      </FuturisticCard>

      <FuturisticCard glow={selectedMonetaryScope.isComparable && selectedNetPnL > 0 ? 'emerald' : selectedMonetaryScope.isComparable && selectedNetPnL < 0 ? 'red' : 'none'} className="p-5">
        <SectionHeader
          eyebrow="Tag"
          title={selectedSummary ? `${String(selectedSummary.day).padStart(2, '0')}. ${monthNames[selectedSummary.month]} ${selectedSummary.year}` : 'Kein Handelstag'}
          badge={selectedSummary ? `${selectedSummary.tradeCount} Trades` : '0 Trades'}
        />

        {selectedSummary ? (
          <div className="space-y-4">
            <div className="rounded-3xl border border-orange-400/15 bg-black/25 p-5">
              <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                <div>
                  <p className="text-[10px] uppercase tracking-[0.24em] text-white/35">Trade</p>
                  <h3 className="mt-3 text-lg font-semibold text-orange-100/90">{featuredTrade ? featuredTrade.market || featuredTrade.setup || 'Fokus-Trade des Tages' : 'Kein Fokus-Trade vorhanden'}</h3>
                </div>
                {featuredTrade ? (
                  <div className="flex flex-wrap items-center gap-2 text-[10px] uppercase tracking-[0.18em] text-white/40">
                    {featuredTradeStatus ? <span className={`rounded-full border px-2 py-1 ${featuredTradeStatus === 'Offen' ? 'border-emerald-400/20 bg-emerald-400/10 text-emerald-200' : featuredTradeStatus === 'Unvollständig' ? 'border-orange-400/20 bg-orange-400/10 text-orange-100/90' : 'border-white/10 bg-white/5 text-white/55'}`}>{featuredTradeStatus}</span> : null}
                    {featuredTrade.direction ? <span className="rounded-full border border-white/10 bg-white/5 px-2 py-1">{featuredTrade.direction}</span> : null}
                    {featuredTrade.setup ? <span className="rounded-full border border-white/10 bg-white/5 px-2 py-1">{featuredTrade.setup}</span> : null}
                  </div>
                ) : null}
              </div>

              {featuredTrade ? (
                <div className="mt-4 grid gap-4 xl:grid-cols-[minmax(0,1.15fr)_minmax(280px,0.85fr)]">
                  <div className="overflow-hidden rounded-3xl border border-white/10 bg-black/30">
                    {featuredTrade.screenshotUrl ? (
                      <SetupImageLightbox
                        src={featuredTrade.screenshotUrl}
                        alt={`${featuredTrade.market || 'Trade'} Screenshot`}
                        badge={featuredTrade.setup || 'Tagesbild'}
                        caption={featuredTrade.date}
                        hint="Klick für Großansicht"
                        className="rounded-none"
                        imageClassName="h-72 w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-72 items-center justify-center text-sm text-white/35">Kein Bild</div>
                    )}
                  </div>

                  <div className="min-w-0 rounded-3xl border border-white/10 bg-white/[0.03] p-4">
                    <p className="text-[10px] uppercase tracking-[0.24em] text-white/35">Kernfakten</p>
                    <div className="mt-4 grid gap-3 sm:grid-cols-2">
                      <MetricTile label="Asset" value={featuredTrade.market || '—'} tone="neutral" />
                      <MetricTile label="Session" value={featuredTrade.session || '—'} tone="neutral" />
                      <MetricTile label="Entry" value={featuredEntry !== undefined && featuredEntry !== null ? String(featuredEntry) : '—'} tone="neutral" />
                      <MetricTile label={featuredPartialPlan?.count ? 'Ø Exit' : 'P&L'} value={featuredPartialPlan?.count && featuredPartialPlan.effectiveExit !== null ? formatPlainNumber(featuredPartialPlan.effectiveExit, 4) : featuredTrade.netPnL !== undefined && featuredTrade.netPnL !== null ? formatCurrency(featuredTrade.netPnL, 2, featuredTrade.accountCurrency) : '—'} tone={featuredPartialPlan?.count ? 'orange' : featuredTrade.netPnL === undefined || featuredTrade.netPnL === null ? 'neutral' : featuredTrade.netPnL >= 0 ? 'emerald' : 'red'} />
                    </div>
                    <div className="mt-4 flex flex-wrap gap-2 text-xs text-white/55">
                      <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5">Konzept: {featuredTrade.concept || '—'}</span>
                      <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5">Qualität: {featuredTrade.quality || '—'}</span>
                      {featuredPartialLabel ? <span className="rounded-full border border-orange-400/20 bg-orange-400/10 px-3 py-1.5 text-orange-100/90">{featuredPartialLabel}</span> : null}
                      {featuredPartialPlan?.summary ? <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5">{featuredPartialPlan.summary}</span> : null}
                    </div>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <Link href={`/trades?tradeId=${encodeURIComponent(featuredTrade.id)}#trade-detail`} className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-2 text-xs text-white/70 transition hover:border-white/15 hover:text-white/90">Trade</Link>
                      <Link href={selectedTradesHref} className="rounded-full border border-orange-400/20 bg-orange-400/10 px-3 py-2 text-xs text-orange-100/90 transition hover:border-orange-400/30 hover:bg-orange-400/15">Trades des Tages</Link>
                    </div>
                  </div>
                </div>
              ) : null}
            </div>

            <div className="rounded-3xl border border-white/10 bg-black/25 p-5">
              <p className="text-[10px] uppercase tracking-[0.24em] text-white/35">Tag im Überblick</p>
              <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                <MetricTile label="P&amp;L" value={selectedMonetaryScope.isComparable ? formatCurrency(selectedNetPnL, 0, selectedMonetaryScope.currency) : 'Gesperrt'} tone={selectedMonetaryScope.isComparable ? selectedNetPnL >= 0 ? 'emerald' : 'red' : 'neutral'} />
                <MetricTile label="Ø R" value={`${selectedAvgR >= 0 ? '+' : ''}${selectedAvgR.toFixed(2)}R`} tone={selectedAvgR >= 0 ? 'emerald' : 'red'} />
                <MetricTile label="Offen" value={String(selectedSummary.openTradeCount)} tone={selectedSummary.openTradeCount ? 'emerald' : 'neutral'} />
                <MetricTile label="Bilder" value={String(selectedSummary.screenshotTradeCount)} tone={selectedSummary.screenshotTradeCount ? 'orange' : 'neutral'} />
              </div>
              {!selectedMonetaryScope.isComparable && selectedMonetaryScope.kind !== 'empty' ? <p className="mt-3 text-xs leading-5 text-orange-100/80">{getMonetaryScopeMessage(selectedMonetaryScope)}</p> : null}
              <div className="mt-4 flex flex-wrap gap-2 text-xs text-white/58">
                {selectedSetups.length ? selectedSetups.map((setup) => <span key={setup} className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5">{setup}</span>) : <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5">Kein Setup hinterlegt</span>}
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <Link href={`/review?date=${selectedDateKey}`} className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-2 text-xs text-white/70 transition hover:border-white/15 hover:text-white/90">Review</Link>
                <Link href="/review" className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-2 text-xs text-white/70 transition hover:border-white/15 hover:text-white/90">Woche</Link>
                <Link href={selectedTradesHref} className="rounded-full border border-orange-400/20 bg-orange-400/10 px-3 py-2 text-xs text-orange-100/90 transition hover:border-orange-400/30 hover:bg-orange-400/15">Trades anzeigen</Link>
              </div>
            </div>

            <div className="rounded-3xl border border-orange-400/15 bg-black/25 p-5">
              <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                <div>
                  <p className="text-[10px] uppercase tracking-[0.24em] text-white/35">Risikorahmen des Tages</p>
                  <h3 className="mt-3 text-lg font-semibold text-orange-100/90">Risiko</h3>
                </div>
                <Link href={selectedTrades.length ? `/trades?reviewTradeIds=${encodeURIComponent(selectedTrades.map((trade) => trade.id).join(','))}&reviewFocus=${encodeURIComponent(`Risk-Check · ${selectedDateKey}`)}` : '/trades'} className="shrink-0 rounded-full border border-orange-400/20 bg-orange-400/10 px-3 py-2 text-xs text-orange-100/90 transition hover:border-orange-400/30 hover:bg-orange-400/15">Risk-Check</Link>
              </div>

              <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                <MetricTile label="Geplantes Risiko" value={selectedPlannedRisk ? selectedMonetaryScope.isComparable ? formatCurrency(selectedPlannedRisk, 0, selectedMonetaryScope.currency) : 'Gesperrt' : '—'} tone={selectedPlannedRisk && selectedMonetaryScope.isComparable ? 'orange' : 'neutral'} />
                <MetricTile label="Stop-Risiko" value={selectedStopRisk ? selectedMonetaryScope.isComparable ? formatCurrency(selectedStopRisk, 0, selectedMonetaryScope.currency) : 'Gesperrt' : '—'} tone={selectedStopRisk && selectedMonetaryScope.isComparable ? 'red' : 'neutral'} />
                <MetricTile label="Gebundene Margin" value={selectedMarginUsed ? selectedMonetaryScope.isComparable ? formatCurrency(selectedMarginUsed, 0, selectedMonetaryScope.currency) : 'Gesperrt' : '—'} tone={selectedMarginUsed && selectedMonetaryScope.isComparable ? 'orange' : 'neutral'} />
                <MetricTile label="Höchster Hebel" value={selectedHighestLeverage ? `${formatPlainNumber(selectedHighestLeverage, 2)}x` : '—'} tone={selectedHighestLeverage > 1 ? 'orange' : 'neutral'} />
                <MetricTile label="Kontorisiko" value={selectedRiskCoverageCount ? `${selectedRiskCoverageCount}/${selectedTrades.length} Trades mit Konto-Risiko` : 'Noch kein Kontorisiko'} tone={selectedRiskCoverageCount ? 'emerald' : 'neutral'} />
                <MetricTile label="Max. Konto-Risiko" value={selectedHighestRiskPercent ? `${formatPlainNumber(selectedHighestRiskPercent, 2)}%` : '—'} tone={selectedHighestRiskPercent ? (selectedHighestRiskPercent > 1 ? 'red' : 'orange') : 'neutral'} />
              </div>

              <div className="mt-4 flex flex-wrap gap-2 text-xs text-white/58">
                <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5">{selectedSummary.riskTradeCount} Trades mit Risk-Kontext</span>
                <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5">{selectedHighestRiskPercent ? `max ${formatPlainNumber(selectedHighestRiskPercent, 2)}% Konto` : 'Kein Kontorisiko ableitbar'}</span>
                <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5">{selectedSummary.marginUsed ? selectedMonetaryScope.isComparable ? `${formatCurrency(selectedSummary.marginUsed, 0, selectedMonetaryScope.currency)} Margin im Tag` : 'Margin-Summe gesperrt' : 'Noch keine Margin im Tag erfasst'}</span>
              </div>
            </div>

            <div className="rounded-3xl border border-white/10 bg-black/25 p-5">
              <div className="flex items-center justify-between gap-3 border-b border-white/10 pb-3">
                <div>
                  <p className="text-[10px] uppercase tracking-[0.24em] text-white/35">Trades des Tages</p>
                  
                </div>
                <span className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-xs text-white/60">{selectedTrades.length} Einträge</span>
              </div>

              <div className="mt-3 space-y-3">
                {selectedTrades.map((trade) => {
                  const hasImage = Boolean(trade.screenshotUrl || (trade.screenshotCount ?? 0) > 0 || (trade.screenshotUrls?.length ?? 0) > 0)
                  const isOpen = trade.captureResult === 'open'
                  const isIncomplete = trade.captureStatus === 'incomplete' || trade.isComplete === false
                  const actionHref = isOpen
                    ? `/trades?tradeId=${encodeURIComponent(trade.id)}&closeTradeId=${encodeURIComponent(trade.id)}#trade-editor`
                    : isIncomplete
                      ? `/trades?tradeId=${encodeURIComponent(trade.id)}&editTradeId=${encodeURIComponent(trade.id)}#trade-editor`
                      : `/trades?tradeId=${encodeURIComponent(trade.id)}`

                  return (
                    <div key={trade.id} className="grid gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-3 md:grid-cols-[1fr_auto] md:items-center">
                      <div className="min-w-0 space-y-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="text-sm font-semibold text-white">{trade.market || 'Unbenannter Trade'}</p>
                          {trade.direction ? <span className="rounded-full border border-white/10 bg-white/[0.03] px-2 py-1 text-[10px] uppercase tracking-[0.18em] text-white/55">{trade.direction}</span> : null}
                          <span className={`rounded-full px-2 py-1 text-[10px] uppercase tracking-[0.18em] ${isOpen ? 'border border-emerald-400/20 bg-emerald-400/10 text-emerald-200' : isIncomplete ? 'border border-orange-400/20 bg-orange-400/10 text-orange-100/90' : 'border border-white/10 bg-white/[0.03] text-white/60'}`}>
                            {isOpen ? 'Offen' : isIncomplete ? 'Unvollständig' : 'Geschlossen'}
                          </span>
                          {hasImage ? <span className="rounded-full border border-orange-400/20 bg-orange-400/10 px-2 py-1 text-[10px] uppercase tracking-[0.18em] text-orange-100/90">Bild</span> : null}
                        </div>
                        <div className="flex flex-wrap gap-3 text-xs text-white/52">
                          <span>Setup: {trade.setup || '—'}</span>
                          <span>Session: {trade.session || '—'}</span>
                          <span>P&amp;L: {trade.netPnL === undefined || trade.netPnL === null ? '—' : formatCurrency(trade.netPnL, 2, trade.accountCurrency)}</span>
                          <span>Risk: {trade.actualRiskPercent !== null && trade.actualRiskPercent !== undefined ? `${formatPlainNumber(trade.actualRiskPercent, 2)}% Konto` : trade.marginUsed ? `${formatCurrency(trade.marginUsed, 0, trade.accountCurrency)} Margin` : '—'}</span>
                          {trade.partialExitCoveragePercent ? <span>TP: {formatPartialExitCoverageLabel(trade.partialExitCoveragePercent, trade.partialExitRemainderPercent ?? null)}</span> : null}
                        </div>
                      </div>

                      <div className="flex flex-col items-stretch gap-2 md:w-40">
                        <Link href={`/trades?tradeId=${encodeURIComponent(trade.id)}#trade-detail`} className="rounded-2xl border border-white/10 bg-white/[0.03] px-3 py-2 text-center text-xs text-white/65 transition hover:border-white/15 hover:text-white/85">Trade</Link>
                        <Link href={actionHref} className="rounded-2xl border border-orange-400/20 bg-orange-400/10 px-3 py-2 text-center text-xs text-orange-100/90 transition hover:border-orange-400/30 hover:bg-orange-400/15">{isOpen ? 'Schließen' : isIncomplete ? 'Vervollständigen' : 'Ansehen'}</Link>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            {remainingScreenshotTrades.length ? (
              <div className="rounded-3xl border border-white/10 bg-black/25 p-5">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-[10px] uppercase tracking-[0.24em] text-white/35">Bilder</p>
                  </div>
                  <Link href={selectedScreenshots[0] ? `/trades?tradeId=${encodeURIComponent(selectedScreenshots[0].id)}#trade-detail` : '/trades'} className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-xs text-white/65 transition hover:border-white/15 hover:text-white/85">Trades</Link>
                </div>
                <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                  {remainingScreenshotTrades.slice(0, 3).map((trade) => (
                    <div key={trade.id} className="space-y-2 overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] p-1.5">
                      <SetupImageLightbox
                        src={trade.screenshotUrl!}
                        alt={`${trade.market} Screenshot`}
                        badge={trade.setup || 'Trade-Screenshot'}
                        caption={trade.date}
                        hint="Klick für Großansicht"
                        className="rounded-xl"
                        imageClassName="h-32 w-full rounded-xl object-cover"
                      />
                      <Link href={`/trades?tradeId=${encodeURIComponent(trade.id)}#trade-detail`} className="inline-flex w-full items-center justify-center rounded-xl border border-white/10 bg-black/25 px-3 py-2 text-xs text-white/70 transition hover:border-white/15 hover:text-white/90">Trade</Link>
                    </div>
                  ))}
                </div>
              </div>
            ) : null}
          </div>
        ) : null}
      </FuturisticCard>
    </div>
  )
}

function CalendarHighlightTile({
  label,
  value,
  detail,
  tone,
  icon,
}: {
  label: string
  value: string
  detail: string
  tone: 'emerald' | 'red' | 'orange'
  icon: 'spark' | 'scan' | 'calendar' | 'trades' | 'focus' | 'cost'
}) {
  const toneClasses = tone === 'emerald'
    ? 'border-emerald-400/15 bg-black/20 text-emerald-300'
    : tone === 'red'
      ? 'border-red-400/15 bg-black/20 text-red-300'
      : 'border-orange-400/15 bg-black/20 text-orange-100/90'

  return (
    <div className={`rounded-2xl border px-4 py-4 ${toneClasses}`}>
      <div className="flex items-center justify-between gap-3">
        <p className="text-[10px] uppercase tracking-[0.24em] text-white/35">{label}</p>
        <AppIcon name={icon} className="h-4 w-4 text-white/45" />
      </div>
      <p className="mt-2 text-xl font-semibold">{value}</p>
      <p className="mt-1 text-sm text-white/48">{detail}</p>
    </div>
  )
}

function MetricTile({ label, value, tone }: { label: string; value: string; tone: 'emerald' | 'red' | 'orange' | 'neutral' }) {
  const toneClass = tone === 'emerald' ? 'text-emerald-300' : tone === 'red' ? 'text-red-300' : tone === 'orange' ? 'text-orange-100/90' : 'text-white'

  return (
    <div className="min-w-0 rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-4">
      <p className="text-[10px] uppercase tracking-[0.22em] text-white/35">{label}</p>
      <p className={`mt-2 break-words text-base font-semibold leading-snug sm:text-lg ${toneClass}`}>{value}</p>
    </div>
  )
}
